window.addEventListener("load",function () {
    const color_input = document.querySelector("#woocommerce_kkiapay_woocommerce_plugin_theme");
    if (color_input) color_input.className += "jscolor"

});
