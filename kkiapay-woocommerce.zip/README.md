## Kkiapay

KkiaPay allows businesses to safely receive payments by mobile money, credit card and bank account.

Kkiapay is developer friendly solution that allows you to accept mobile money and credit card, and direct bank payments in your application or website. Before using this plugin, make sure you have a right Merchant Account on Kkiapay, otherwise go and create your account. It is free and without pain.

KKIAPAY is available in:

* Benin
* Côte d'Ivoire
* Togo
* Senegal
* [More details at ](https://kkiapay.me/features/supported-countries)

## Installation

Please refer to : https://wordpress.org/plugins/kkiapay-woocommerce-plugin
